Manual del usuario de Buscaminacum 2020
------------Sistemas UNIX------------------------

Jugar un partida.

1. Debe seleccionar en JUGAR.
2. Elegir el NIVEL.
3. Jugar eligiendo fila y columna.
4. Puede ir marcando las casillas.


Reglas.

1. Elegir una casilla oculta.
2. Los numeros al pulsar la casilla oculta 
indican la cantidad de minas que hay alrededor.
3. Puede marcar una casilla.
4. El color y el fondo de la casilla cambia al 
elegirla.
5. Cuando acabe la partida o pierda puede 
volver a jugar.


-------------------------------------------------